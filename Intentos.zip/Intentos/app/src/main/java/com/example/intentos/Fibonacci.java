package com.example.intentos;

public class Fibonacci {

    public Integer fivonacci(){

        if(edtInput == 0){

            return 1;

        }

        if(edtInput == 1){



        }


    }
